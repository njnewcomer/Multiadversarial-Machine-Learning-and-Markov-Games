"""Two fixed players to measure learned players against.

Both act from a player's own (mirrored) observation, so the same function
plays red or blue:  obs = [own_x, own_y, opp_x, opp_y, ball_x, ball_y, bvx, bvy],
and the player always attacks the goal at x = W.
"""
import numpy as np
from .env import W, H, RP, RB, V_MAX

GOAL = np.array([W + 0.04, 0.5])     # a point inside the attacked pocket


class RandomPlayer:
    """Uniformly random desired velocity in the speed disk, every step."""

    def __init__(self, seed=0):
        self.rng = np.random.default_rng(seed)

    def __call__(self, obs):
        n = len(obs)
        r = V_MAX * np.sqrt(self.rng.uniform(0, 1, n))
        t = self.rng.uniform(-np.pi, np.pi, n)
        return np.stack([r * np.cos(t), r * np.sin(t)], 1)


def chaser(obs):
    """Scripted chaser: get behind the ball on the line from the goal, then
    run through the ball toward the goal.

    1. aim = point behind the ball, opposite the goal, at touching distance
    2. if the player is in front of the ball (between ball and goal), go
       around it: first to a point beside the ball
    3. once at the aim point, run toward the goal through the ball
    """
    me, ball = obs[:, 0:2], obs[:, 4:6]
    g = GOAL - ball
    gdir = g / np.maximum(np.linalg.norm(g, axis=1, keepdims=True), 1e-9)
    aim = ball - gdir * (RP + RB + 0.005)
    to_ball = ball - me
    ahead = np.sum(-to_ball * gdir, 1) > 0          # player is goal-side of the ball
    side = np.stack([-gdir[:, 1], gdir[:, 0]], 1)
    sgn = np.sign(np.sum((me - ball) * side, 1)); sgn[sgn == 0] = 1
    detour = ball + side * sgn[:, None] * (RP + RB + 0.04) - gdir * 0.02
    target = np.where(ahead[:, None], detour, aim)
    at_aim = (~ahead) & (np.linalg.norm(me - aim, axis=1) < 0.03)
    move = np.where(at_aim[:, None], gdir, target - me)
    n = np.linalg.norm(move, axis=1, keepdims=True)
    return move / np.maximum(n, 1e-9) * V_MAX
