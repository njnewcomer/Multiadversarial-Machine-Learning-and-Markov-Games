"""Step 1 checks: does the Rink behave like the rules say? No learning."""
import json
import numpy as np
from .env import (Rink, W, H, RP, RB, RC, MOUTH, DEPTH, DT, FRICTION, rink_project)

still = lambda n: np.zeros((n, 2))
R = {}


def ball_only(b0, v0, steps=400):
    """Players parked far away (both at kickoff, not moving). Track the ball."""
    n = len(b0)
    env = Rink(n, seed=1, jitter=0.0)
    env.pR[:] = [-5, -5]; env.pB[:] = [-5, -5]       # out of the way (never projected while still)
    env.b[:] = b0; env.vb[:] = v0; env.anchor[:] = b0
    path = [env.b.copy()]; goals = np.zeros(n, int)
    for _ in range(steps):
        if env.done.all():
            break
        env.pR[:] = [-5, -5]; env.pB[:] = [-5, -5]
        _, (rR, _), _, info = env.step(still(n), still(n))
        goals += rR.astype(int)
        path.append(env.b.copy())
    return np.array(path), goals, env


def inside_rink(p, r, allow_pocket):
    q, nrm = rink_project(p, r)
    ok = np.linalg.norm(q - p, axis=1) < 1e-9
    if allow_pocket:
        from .env import POSTS
        clear = np.min(np.linalg.norm(p[:, None, :] - POSTS[None], axis=2), 1) >= r - 1e-9
        inpk = ((p[:, 0] < r) | (p[:, 0] > W - r)) & (p[:, 1] >= MOUTH[0]) & (p[:, 1] <= MOUTH[1]) & clear
        ok |= inpk
    return ok


# 1. friction: free ball slows as exp(-FRICTION t)
path, _, env = ball_only(np.array([[0.75, 0.5]]), np.array([[0.3, 0.0]]), steps=20)
speed_ratio = np.linalg.norm(env.vb[0]) / 0.3
R["friction"] = dict(expected=float(np.exp(-FRICTION * 20 * DT)), got=float(speed_ratio))

# 2. straight-wall bounce: ball fired at the top wall comes back with E_BW of its speed
path, _, env = ball_only(np.array([[0.75, 0.9]]), np.array([[0.0, 1.0]]), steps=8)
R["wall_bounce_vy_after"] = float(env.vb[0, 1])

# 3. corner bounce: ball fired into a rounded corner stays inside and comes back
path, _, env = ball_only(np.array([[1.2, 0.7]]), np.array([[1.0, 1.0]]), steps=60)
R["corner"] = dict(max_outside=float(np.max(np.linalg.norm(rink_project(path[:, 0], RB)[0] - path[:, 0], axis=1))),
                   end=path[-1, 0].round(3).tolist())

# 4. goals: balls fired straight into each pocket score for the right side
path, goals, env = ball_only(np.array([[1.3, 0.5], [0.2, 0.5]]), np.array([[1.2, 0.0], [-1.2, 0.0]]), steps=40)
R["goals"] = dict(right_pocket_red_reward=int(goals[0]), left_pocket_red_reward=int(goals[1]))

# 5. post: ball fired just inside the post deflects and does not score
path, goals, env = ball_only(np.array([[1.3, 0.345]]), np.array([[1.2, 0.0]]), steps=40)
R["post"] = dict(red_reward=int(goals[0]), end=path[-1, 0].round(3).tolist())

# 6. miss: ball fired at the end wall outside the mouth bounces back
path, goals, env = ball_only(np.array([[1.3, 0.25]]), np.array([[1.2, 0.0]]), steps=30)
R["end_wall"] = dict(red_reward=int(goals[0]), vx_after=float(env.vb[0, 0]))

# 7. random play stress test: nobody leaves the rink, players never overlap
env = Rink(500, seed=3)
rng = np.random.default_rng(0)
worst_pp, worst_out_p, worst_out_b = 0.0, 0.0, 0.0
for _ in range(400):
    a = rng.normal(0, 1, (500, 2)); c = rng.normal(0, 1, (500, 2))
    env.step(a, c)
    live = ~env.done
    if not live.any():
        break
    d = np.linalg.norm(env.pR - env.pB, axis=1)[live]
    worst_pp = max(worst_pp, float(np.max(2 * RP - d)))
    for p, r in ((env.pR, RP), (env.pB, RP)):
        worst_out_p = max(worst_out_p, float(np.max(np.linalg.norm(rink_project(p[live], r)[0] - p[live], axis=1))))
    ok = inside_rink(env.b[live], RB, True)
    worst_out_b = max(worst_out_b, float(np.mean(~ok)))
R["stress"] = dict(max_player_overlap=worst_pp, max_player_outside=worst_out_p, share_ball_outside=worst_out_b)

# 8. stall rule: two still players and a still ball restart after STALL_STEPS
env = Rink(1, seed=0)
stalls = 0
for _ in range(130):
    _, _, _, info = env.step(still(1), still(1))
    stalls += int(info["stall"][0])
R["stall_restarts_in_130_steps"] = stalls

json.dump(R, open("rink/results_physics.json", "w"), indent=1)
for k, v in R.items():
    print(k, v)
