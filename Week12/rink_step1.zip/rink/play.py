"""Run matches between two policies and record results (and optional replays)."""
import numpy as np
from .env import Rink


def match(red, blue, n=1000, seed=0, record=0):
    """red, blue: functions obs -> action (in their own frame).
    Returns dict of outcome counts and up to `record` replays."""
    env = Rink(n, seed=seed)
    oR, oB = env.obs()
    frames = [env.snapshot()[:record]] if record else None
    goal_t = np.full(n, -1)
    red_w = np.zeros(n, bool); blue_w = np.zeros(n, bool)
    while not env.done.all():
        (oR, oB), _, done, info = env.step(red(oR), blue(oB))
        red_w |= info["red_goal"]; blue_w |= info["blue_goal"]
        goal_t[(info["red_goal"] | info["blue_goal"])] = env.t[(info["red_goal"] | info["blue_goal"])]
        if record:
            frames.append(env.snapshot()[:record])
    out = dict(red_wins=int(red_w.sum()), blue_wins=int(blue_w.sum()),
               draws=int((~red_w & ~blue_w).sum()), n=n,
               mean_goal_time_s=float(goal_t[goal_t > 0].mean() * 0.05) if (goal_t > 0).any() else None,
               stall_restarts_per_game=float(env.stalls.mean()))
    if record:
        F = np.stack(frames, 1)              # (record, T+1, 6)
        out["replays"] = F
        out["replay_len"] = env.t[:record].tolist()
        out["replay_result"] = ["red" if red_w[i] else "blue" if blue_w[i] else "draw" for i in range(record)]
    return out
