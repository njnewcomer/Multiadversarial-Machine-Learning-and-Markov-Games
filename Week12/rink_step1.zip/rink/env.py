"""The Rink: a 1 v 1 continuous-action soccer game (our own implementation).

Geometry (units: field widths are 1.5 x 1.0)
  * Rink: rounded rectangle [0, 1.5] x [0, 1], corner radius 0.2.
  * Goals: pockets in the middle of each short wall, mouth y in [0.35, 0.65],
    depth 0.08. Red defends the LEFT pocket and attacks RIGHT; blue the reverse.
  * A goal counts when the whole ball is inside a pocket.

Bodies
  * Players: discs of radius 0.04. Action = desired velocity (vx, vy),
    clipped to a disk of radius V_MAX. Players cannot enter the pockets.
  * Ball: disc of radius 0.025 with friction; bounces off walls and posts.

Contacts (all simple, positional)
  * player-wall: pushed back inside, normal velocity removed
  * player-player: pushed apart equally
  * player-ball: ball pushed out of the player; if they approach, the ball's
    relative normal velocity is reflected with restitution E_PB (player is
    treated as much heavier). This is how the ball is dribbled and kicked.
  * ball-wall / ball-post: reflected with restitution E_BW

Time: steps of DT = 0.05. Episode ends on a goal or after T_MAX steps.
Stall rule: if the ball moves less than STALL_DIST in STALL_STEPS steps,
the game restarts from kickoff (no reward).
Reward: +1 to the scorer, -1 to the other, 0 otherwise.

All games run in parallel: every state array has a leading batch axis N.
"""
import numpy as np

W, H = 1.5, 1.0
RC = 0.2                     # corner radius
MOUTH = (0.35, 0.65)         # goal mouth y-range
DEPTH = 0.08                 # pocket depth
RP, RB = 0.04, 0.025         # player and ball radii
V_MAX = 0.6                  # player max speed (field units per second)
BALL_VMAX = 1.5
FRICTION = 1.0               # ball speed decays as exp(-FRICTION * t)
E_PB, E_BW = 0.5, 0.8        # restitution: player-ball, ball-wall
DT = 0.05
T_MAX = 400                  # 20 seconds
STALL_STEPS, STALL_DIST = 60, 0.05
KICKOFF_RED = np.array([0.25, 0.5])
KICKOFF_BLUE = np.array([1.25, 0.5])
CENTER = np.array([0.75, 0.5])
POSTS = np.array([[0.0, MOUTH[0]], [0.0, MOUTH[1]], [W, MOUTH[0]], [W, MOUTH[1]]])


def clip_disk(v, vmax):
    n = np.linalg.norm(v, axis=-1, keepdims=True)
    return v * np.minimum(1.0, vmax / np.maximum(n, 1e-12))


def rink_project(p, r):
    """Push discs of radius r back inside the rounded rectangle.
    Returns new positions and the inward unit normal where a push happened
    (zero vector where no contact)."""
    p = p.copy()
    nrm = np.zeros_like(p)
    # straight walls
    lo = np.array([r, r]); hi = np.array([W - r, H - r])
    for k in range(2):
        under = p[:, k] < lo[k]; over = p[:, k] > hi[k]
        p[under, k] = lo[k]; nrm[under, k] = 1.0
        p[over, k] = hi[k]; nrm[over, k] = -1.0
    # rounded corners: centres at (RC, RC), (W-RC, RC), ...
    cx = np.where(p[:, 0] < RC, RC, np.where(p[:, 0] > W - RC, W - RC, np.nan))
    cy = np.where(p[:, 1] < RC, RC, np.where(p[:, 1] > H - RC, H - RC, np.nan))
    inc = ~np.isnan(cx) & ~np.isnan(cy)
    if inc.any():
        c = np.stack([cx[inc], cy[inc]], 1)
        d = p[inc] - c
        dist = np.linalg.norm(d, axis=1)
        out = dist > RC - r
        if out.any():
            u = d[out] / dist[out, None]
            idx = np.where(inc)[0][out]
            p[idx] = c[out] + u * (RC - r)
            nrm[idx] = -u
    return p, nrm


def ball_bounds(b, v):
    """Ball against rink walls, goal pockets and posts. Returns b, v."""
    b = b.copy(); v = v.copy()
    in_mouth = (b[:, 1] > MOUTH[0]) & (b[:, 1] < MOUTH[1])
    near_left = b[:, 0] < RB; near_right = b[:, 0] > W - RB
    inside_pocket = ((b[:, 0] < 0) | (b[:, 0] > W)) & (b[:, 1] >= MOUTH[0]) & (b[:, 1] <= MOUTH[1])
    pocket = (in_mouth & (near_left | near_right)) | inside_pocket
    # (1) rink walls for balls not heading into a pocket
    rb, nrm = rink_project(b[~pocket], RB)
    vv = v[~pocket]
    vn = np.sum(vv * nrm, 1)
    hit = vn < 0
    vv[hit] -= (1 + E_BW) * vn[hit, None] * nrm[hit]
    b[~pocket] = rb; v[~pocket] = vv
    # (2) inside a pocket: back wall and the pocket's side walls
    if pocket.any():
        bp, vp = b[pocket], v[pocket]
        left = bp[:, 0] < W / 2
        back = np.where(left, -DEPTH + RB, W + DEPTH - RB)
        past = np.where(left, bp[:, 0] < back, bp[:, 0] > back)
        bp[past, 0] = back[past]; vp[past, 0] *= -E_BW
        inside = np.where(left, bp[:, 0] < 0, bp[:, 0] > W)
        for lim, sgn in ((MOUTH[0] + RB, 1), (MOUTH[1] - RB, -1)):
            bad = inside & (sgn * (bp[:, 1] - lim) < 0)
            bp[bad, 1] = lim
            vp[bad, 1] = np.where(sgn * vp[bad, 1] < 0, -E_BW * vp[bad, 1], vp[bad, 1])
        b[pocket], v[pocket] = bp, vp
    # (3) posts
    for post in POSTS:
        d = b - post
        dist = np.linalg.norm(d, axis=1)
        hit = dist < RB
        if hit.any():
            u = d[hit] / np.maximum(dist[hit, None], 1e-12)
            b[hit] = post + u * RB
            vn = np.sum(v[hit] * u, 1)
            v[hit] -= np.where(vn < 0, (1 + E_BW) * vn, 0)[:, None] * u
    return b, v


def separate(p1, p2, r1, r2):
    """Equal push-apart of overlapping discs. Returns new p1, p2, normal 1->2."""
    d = p2 - p1
    dist = np.linalg.norm(d, axis=1)
    u = d / np.maximum(dist[:, None], 1e-12)
    over = np.maximum(r1 + r2 - dist, 0)[:, None]
    return p1 - u * over / 2, p2 + u * over / 2, u, over[:, 0] > 0


def player_ball(p, vp, b, vb):
    """Ball pushed out of the player; relative approach reflected."""
    d = b - p
    dist = np.linalg.norm(d, axis=1)
    u = d / np.maximum(dist[:, None], 1e-12)
    touch = dist < RP + RB
    b = np.where(touch[:, None], p + u * (RP + RB), b)
    rel = np.sum((vb - vp) * u, 1)
    hit = touch & (rel < 0)
    vb = vb - np.where(hit, (1 + E_PB) * rel, 0)[:, None] * u
    return b, vb, touch


class Rink:
    def __init__(self, n, seed=0, jitter=0.03):
        self.n = n
        self.rng = np.random.default_rng(seed)
        self.jitter = jitter
        self.reset()

    # ------------------------------------------------------------ state
    def kickoff(self, mask):
        k = int(mask.sum())
        if k == 0:
            return
        j = lambda: self.rng.uniform(-self.jitter, self.jitter, (k, 2))
        self.pR[mask] = KICKOFF_RED + j()
        self.pB[mask] = KICKOFF_BLUE + j()
        self.b[mask] = CENTER + j()
        self.vR[mask] = 0; self.vB[mask] = 0; self.vb[mask] = 0
        self.anchor[mask] = self.b[mask]
        self.since[mask] = 0

    def reset(self):
        n = self.n
        self.pR = np.zeros((n, 2)); self.pB = np.zeros((n, 2)); self.b = np.zeros((n, 2))
        self.vR = np.zeros((n, 2)); self.vB = np.zeros((n, 2)); self.vb = np.zeros((n, 2))
        self.anchor = np.zeros((n, 2)); self.since = np.zeros(n, int)
        self.t = np.zeros(n, int)
        self.done = np.zeros(n, bool)
        self.stalls = np.zeros(n, int)
        self.kickoff(np.ones(n, bool))
        return self.obs()

    # ------------------------------------------------------------ observations
    def obs(self):
        """Each player sees itself attacking RIGHT (blue's view is mirrored in x).
        8 numbers: own pos, opponent pos, ball pos, ball vel."""
        def mir(p):
            return np.stack([W - p[:, 0], p[:, 1]], 1)
        oR = np.concatenate([self.pR, self.pB, self.b, self.vb], 1)
        vbm = np.stack([-self.vb[:, 0], self.vb[:, 1]], 1)
        oB = np.concatenate([mir(self.pB), mir(self.pR), mir(self.b), vbm], 1)
        return oR, oB

    # ------------------------------------------------------------ dynamics
    def step(self, aR, aB_mirrored):
        """aR: red's desired velocity. aB_mirrored: blue's action in its own
        (mirrored) frame; un-mirrored here. Returns obs, (rR, rB), done, info."""
        live = ~self.done
        aB = np.stack([-aB_mirrored[:, 0], aB_mirrored[:, 1]], 1)
        self.vR = clip_disk(np.asarray(aR, float), V_MAX)
        self.vB = clip_disk(aB, V_MAX)
        self.vR[~live] = 0; self.vB[~live] = 0
        # move
        self.pR = self.pR + self.vR * DT
        self.pB = self.pB + self.vB * DT
        self.vb = clip_disk(self.vb * np.exp(-FRICTION * DT), BALL_VMAX)
        self.vb[~live] = 0
        self.b = self.b + self.vb * DT
        # contacts (a few relaxation passes)
        for _ in range(3):
            self.pR, self.pB, _, _ = separate(self.pR, self.pB, RP, RP)
            # random order per game, so neither colour always touches the ball last
            first_red = (self.rng.random(self.n) < 0.5)[:, None]
            p1, v1 = np.where(first_red, self.pR, self.pB), np.where(first_red, self.vR, self.vB)
            p2, v2 = np.where(first_red, self.pB, self.pR), np.where(first_red, self.vB, self.vR)
            self.b, self.vb, _ = player_ball(p1, v1, self.b, self.vb)
            self.b, self.vb, _ = player_ball(p2, v2, self.b, self.vb)
            self.pR, nR = rink_project(self.pR, RP)
            self.pB, nB = rink_project(self.pB, RP)
            self.b, self.vb = ball_bounds(self.b, self.vb)
        self.vb = clip_disk(self.vb, BALL_VMAX)
        # scoring
        red_goal = live & (self.b[:, 0] > W + RB)     # ball fully in right pocket
        blue_goal = live & (self.b[:, 0] < -RB)
        rR = red_goal.astype(float) - blue_goal.astype(float)
        # stall rule
        self.since += live
        moved = np.linalg.norm(self.b - self.anchor, axis=1) > STALL_DIST
        self.anchor[moved] = self.b[moved]; self.since[moved] = 0
        stall = live & ~red_goal & ~blue_goal & (self.since >= STALL_STEPS)
        self.stalls += stall
        self.kickoff(stall)
        # time and termination
        self.t += live
        timeout = live & (self.t >= T_MAX)
        newly = red_goal | blue_goal | timeout
        self.done = self.done | newly
        info = dict(red_goal=red_goal, blue_goal=blue_goal, timeout=timeout & ~red_goal & ~blue_goal,
                    stall=stall)
        return self.obs(), (rR, -rR), self.done.copy(), info

    def snapshot(self):
        return np.concatenate([self.pR, self.pB, self.b], 1).copy()
