"""Step 1 matches: random and scripted chaser against each other, both sides."""
import json
import numpy as np
from .play import match
from .yardsticks import RandomPlayer, chaser

N = 2000
rows = []
pairs = [
    ("random", "random"),
    ("chaser", "random"),
    ("random", "chaser"),
    ("chaser", "chaser"),
]
replays = {}
for red_name, blue_name in pairs:
    red = chaser if red_name == "chaser" else RandomPlayer(seed=11)
    blue = chaser if blue_name == "chaser" else RandomPlayer(seed=12)
    out = match(red, blue, n=N, seed=5, record=4)
    replays[f"{red_name} (red) vs {blue_name} (blue)"] = dict(
        frames=np.round(out.pop("replays"), 4).tolist(), lens=out.pop("replay_len"), results=out.pop("replay_result"))
    out.update(red=red_name, blue=blue_name)
    rows.append(out)
    print(out, flush=True)
json.dump(rows, open("rink/results_yardsticks.json", "w"), indent=1)
json.dump(replays, open("rink/replays_step1.json", "w"))
